﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class ButtonScript : MonoBehaviour {

	public Button planet0,planet1,planet2,planet3,planet4,planet5,planet6,planet7,planet8 ;
	public Button CloseBtnn;
	[SerializeField]
	GameObject Panel;

	[SerializeField]
	Text planetData;
	// Use this for initialization
	void Start () {

		Panel.SetActive (false);
		Button btn = planet0.GetComponent<Button>();
		btn.onClick.AddListener(planet_1);
		Button btn1 = planet1.GetComponent<Button>();
		btn1.onClick.AddListener(planet_2);
		Button btn2 = planet2.GetComponent<Button>();
		btn2.onClick.AddListener(planet_3);
		Button btn3 = planet3.GetComponent<Button>();
		btn3.onClick.AddListener(planet_4);
		Button btn4 = planet4.GetComponent<Button>();
		btn4.onClick.AddListener(planet_5);
		Button btn5 = planet5.GetComponent<Button>();
		btn5.onClick.AddListener(planet_6);
		Button btn6 = planet6.GetComponent<Button>();
		btn6.onClick.AddListener(planet_7);
		Button btn7 = planet7.GetComponent<Button>();
		btn7.onClick.AddListener(planet_7);


		Button CloseBtn = CloseBtnn.GetComponent<Button>();
		CloseBtn.onClick.AddListener(Close);

	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void planet_1()
	{
		Panel.SetActive (true);
		planetData.text = "Mercury" +
			"\n\nDiscover:Visible To naked Eyes" +
			"\nNamed For: Message of Roman Gods" +
			"\nDiameter:3031 miles" +
			"\nOrbit: 88 earnth days" +
			"\nDays: 58.6 Days";
	}
	public void planet_2()
	{
		
		Panel.SetActive (true);
		planetData.text = "Venus" +
			"\nDiscover:Visible To naked Eyes" +
			"\nNamed For: Message of Roman Gods" +
			"\nDiameter:3031 miles" +
			"\nOrbit: 88 earnth days" +
			"\nDays: 58.6 Days";
	}
	public void planet_3()
	{
		Panel.SetActive (true);
		planetData.text = "Discover:Visible To naked Eyes" +
			"\nNamed For: Roman Godness of LOVE and Beauty" +
			"\nDiameter:7521 miles" +
			"\nOrbit: 225 earnth days" +
			"\nDays: 241 Days";
	}
	public void planet_4()
	{
		Panel.SetActive (true);
		planetData.text = "\nDiameter:7926 miles" +
			"\nOrbit: 356 earnth days" +
			"\nDays: 24 hours";
	}
	public void planet_5()
	{
		Panel.SetActive (true);
		planetData.text = "Discover:Visible To naked Eyes" +
			"\nNamed For: Roman Godnof war" +
			"\nDiameter:4217 miles" +
			"\nOrbit: 687 earnth days" +
			"\nDays: 24 hours";
	}
	public void planet_6()
	{
		Panel.SetActive (true);
		planetData.text = "Discover:Visible To naked Eyes" +
			"\nNamed For: Rular of Roman God" +
			"\nDiameter:86881 miles" +
			"\nOrbit: 11.9 earnth year" +
			"\nDays: 9.1 earth hours";
	}
	public void planet_7()
	{
		Panel.SetActive (true);
		planetData.text = "Discover:Visible To naked Eyes" +
			"\nNamed For: Roman God of agriculture" +
			"\nDiameter:74900 miles" +
			"\nOrbit: 29.5 earnth years" +
			"\nDays: 10.5 earth hours";
	}

	public void planet_8()
	{
		Panel.SetActive (true);
		planetData.text = "Discover:Visible To naked Eyes" +
			"\nNamed For: Roman God of agriculture" +
			"\nDiameter:31763 miles" +
			"\nOrbit: 84 earnth years" +
			"\nDays: 18 earth hours";
	}
	public void Close()
	{
		Panel.SetActive (false);
	}

}
